package com.example.hugo.bottomnavbar.Search;

public class User {
    public String name;
    public String bio;
    public String userType;
    public String profileImageUrl;
    public User() {}

    public User(String name, String bio, String userType, String profileImageUrl) {
        this.name = name;
        this.bio = bio;
        this.userType = userType;
        this.profileImageUrl = profileImageUrl;
    }
}


